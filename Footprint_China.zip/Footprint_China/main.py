import sys
import json
from pathlib import Path
from collections import defaultdict
from uuid import uuid4

from shapely.geometry import shape, Polygon, MultiPolygon, GeometryCollection
from shapely.ops import unary_union

from PySide6.QtCore import Qt, QDateTime, QUrl, QObject, Slot
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit, QDateTimeEdit,
    QListWidget, QListWidgetItem, QComboBox, QFrame,
    QMessageBox, QSplitter, QFormLayout, QDialog, QProgressBar,
    QCheckBox, QDialogButtonBox
)
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebChannel import QWebChannel


# ==================================================
# 1. 路径与数据
# ==================================================

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
GEOJSON_PATH = DATA_DIR / "china_city.geojson"
VISITED_PATH = DATA_DIR / "visited.json"
ECHARTS_PATH = DATA_DIR / "echarts.min.js"

DATA_DIR.mkdir(exist_ok=True)

if not ECHARTS_PATH.exists():
    raise FileNotFoundError(
        f"找不到本地 ECharts 文件：{ECHARTS_PATH}\n"
        "请将 echarts.min.js 放入 data 文件夹。"
    )

if not GEOJSON_PATH.exists():
    raise FileNotFoundError(f"找不到地图文件：{GEOJSON_PATH}")

with GEOJSON_PATH.open("r", encoding="utf-8") as file:
    GEO_DATA = json.load(file)

CITIES = []
for feature in GEO_DATA["features"]:
    properties = feature["properties"]
    adcode = str(properties["adcode"]).strip()
    CITIES.append({
        "name": properties["name"].strip(),
        "code": adcode,
        "province_code": adcode[:2],
        "province": properties.get("province", ""),
        "geometry": feature["geometry"],
    })

CITIES.sort(key=lambda city: (city["province"], city["name"]))
CITY_BY_CODE = {city["code"]: city for city in CITIES}

DATA_LOAD_WARNING = ""


def normalize_visit(visit):
    """兼容旧版本仅保存 date 的记录，并补齐新字段。"""
    visit.setdefault("id", str(uuid4()))
    visit.setdefault("title", "未命名记录")
    visit.setdefault("content", "")
    visit.setdefault("note", "")

    arrival = str(visit.get("arrival", "")).strip()
    if not arrival:
        old_date = str(visit.get("date", "")).strip()
        if old_date:
            arrival = f"{old_date} 09:00"
        else:
            arrival = QDateTime.currentDateTime().toString("yyyy-MM-dd HH:mm")
    elif len(arrival) == 10:
        arrival = f"{arrival} 09:00"

    visit["arrival"] = arrival
    visit["departure"] = str(visit.get("departure", "") or "").strip()
    # 保留 date 字段，兼容可能读取旧字段的其他工具。
    visit["date"] = arrival[:10]
    return visit


def load_records():
    global DATA_LOAD_WARNING

    if not VISITED_PATH.exists():
        return {}

    try:
        with VISITED_PATH.open("r", encoding="utf-8") as file:
            loaded = json.load(file)

        if not isinstance(loaded, dict):
            raise ValueError("数据文件的顶层结构不是 JSON 对象。")

        for code, city_data in list(loaded.items()):
            if not isinstance(city_data, dict):
                loaded[code] = {"footprint": False, "label": "", "visits": []}
                continue

            visits = city_data.get("visits", [])
            if not isinstance(visits, list):
                visits = []
            city_data["visits"] = [
                normalize_visit(visit)
                for visit in visits
                if isinstance(visit, dict)
            ]
            city_data.setdefault("label", "")

            # 旧版本有些记录没有独立的 footprint 字段。
            # 为避免升级后原有足迹消失，将这类已有日记的城市保留为已添加状态。
            if "footprint" not in city_data:
                city_data["footprint"] = bool(city_data["visits"])
            else:
                city_data["footprint"] = bool(city_data["footprint"])

        return loaded

    except (json.JSONDecodeError, OSError, ValueError) as error:
        DATA_LOAD_WARNING = f"visited.json 无法正常读取：{error}"
        return {}


def save_records():
    temporary_path = VISITED_PATH.with_suffix(".tmp")
    with temporary_path.open("w", encoding="utf-8") as file:
        json.dump(records, file, ensure_ascii=False, indent=4)
    temporary_path.replace(VISITED_PATH)


records = load_records()


# ==================================================
# 2. 生成省级边界
# ==================================================

def get_polygons(geometry):
    if isinstance(geometry, Polygon):
        return [geometry]
    if isinstance(geometry, (MultiPolygon, GeometryCollection)):
        result = []
        for item in geometry.geoms:
            result.extend(get_polygons(item))
        return result
    return []


province_groups = defaultdict(list)
for city in CITIES:
    province_groups[city["province_code"]].append(shape(city["geometry"]))

province_lines = []
for geometries in province_groups.values():
    merged = unary_union(geometries)
    for polygon in get_polygons(merged):
        coordinates = [[float(x), float(y)] for x, y in polygon.exterior.coords]
        province_lines.append({"coords": coordinates})


# ==================================================
# 3. 地图 HTML：点击地图城市时，通过 QWebChannel 通知 Python
# ==================================================

def create_map_html():
    city_data = json.dumps(GEO_DATA, ensure_ascii=False)
    province_data = json.dumps(province_lines, ensure_ascii=False)

    return r"""
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<script src="echarts.min.js"></script>
<script src="qrc:///qtwebchannel/qwebchannel.js"></script>
<style>
html, body {
    margin: 0;
    width: 100%;
    height: 100%;
    overflow: hidden;
    background: #f7f9fc;
}
#map {
    width: 100%;
    height: 100%;
}
</style>
</head>
<body>
<div id="map"></div>
<script>
if (!window.echarts) {
    document.getElementById('map').innerHTML =
        '<div style="padding:30px;color:#B42318;font:16px Microsoft YaHei">本地 ECharts 文件未找到。请将 echarts.min.js 放入 data 文件夹。</div>';
} else {
    const cityGeoJSON = __CITY_DATA__;
    const provinceLines = __PROVINCE_DATA__;
    echarts.registerMap('china_city', cityGeoJSON);

    const chart = echarts.init(document.getElementById('map'));
    const cityCodeByName = {};
    cityGeoJSON.features.forEach(feature => {
        const name = String(feature.properties.name || '').trim();
        const code = String(feature.properties.adcode || '').trim();
        if (name && code) cityCodeByName[name] = code;
    });

    chart.setOption({
        tooltip: {
            trigger: 'item',
            formatter: params => params.name || ''
        },
        geo: {
            map: 'china_city',
            roam: true,
            scaleLimit: { min: 0.8, max: 12 },
            itemStyle: {
                areaColor: '#E8EBEF',
                borderColor: '#FFFFFF',
                borderWidth: 0.8
            },
            emphasis: {
                itemStyle: {
                    areaColor: '#F7DCE5',
                    borderColor: '#FFFFFF',
                    borderWidth: 1
                },
                label: { show: false }
            },
            regions: []
        },
        series: [{
            name: '省级边界',
            type: 'lines',
            coordinateSystem: 'geo',
            data: provinceLines,
            polyline: true,
            silent: true,
            z: 10,
            lineStyle: {
                color: '#718096',
                width: 1.2,
                opacity: 0.55
            }
        }]
    });

    // 只有 Python 收到城市代码后才会检查足迹状态。
    // 未添加足迹的城市由 Python 直接忽略，不弹出窗口。
    let mapBridge = null;
    if (window.qt && qt.webChannelTransport) {
        new QWebChannel(qt.webChannelTransport, function(channel) {
            mapBridge = channel.objects.mapBridge;
        });
    }

    chart.on('click', function(params) {
        const cityName = String(params.name || '').trim();
        const code = cityCodeByName[cityName];
        if (code && mapBridge) {
            mapBridge.cityClicked(code);
        }
    });

    window.updateVisited = function(names) {
        const visited = new Set(names || []);
        const regions = Object.keys(cityCodeByName)
            .filter(name => visited.has(name))
            .map(name => ({
                name: name,
                itemStyle: {
                    areaColor: '#F2B8C9',
                    borderColor: '#FFFFFF',
                    borderWidth: 0.8
                }
            }));
        chart.setOption({ geo: { regions: regions } });
    };

    window.updateVisited(window.__pendingVisited || []);
    window.addEventListener('resize', () => chart.resize());
}
</script>
</body>
</html>
""".replace("__CITY_DATA__", city_data).replace("__PROVINCE_DATA__", province_data)


# ==================================================
# 4. 地图点击桥接对象
# ==================================================

class MapBridge(QObject):
    def __init__(self, main_window):
        super().__init__(main_window)
        self.main_window = main_window

    @Slot(str)
    def cityClicked(self, city_code):
        self.main_window.open_city_from_map(city_code)


# ==================================================
# 5. 单条历史记录编辑窗口
# ==================================================

class RecordEditorDialog(QDialog):
    def __init__(self, parent=None, visit=None):
        super().__init__(parent)
        self.visit = visit or {}
        self.setWindowTitle("编辑历史记录" if visit else "新建历史记录")
        self.resize(590, 610)
        self.setMinimumSize(520, 520)

        layout = QVBoxLayout(self)
        heading = QLabel("编辑历史记录" if visit else "新建历史记录")
        heading.setObjectName("heading")
        layout.addWidget(heading)

        form = QFormLayout()
        form.setSpacing(12)

        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText("给这段经历起一个标题")
        self.title_edit.setText(self.visit.get("title", ""))
        form.addRow("记录标题", self.title_edit)

        self.arrival_edit = QDateTimeEdit()
        self.arrival_edit.setCalendarPopup(True)
        self.arrival_edit.setDisplayFormat("yyyy-MM-dd HH:mm")
        arrival_value = self._parse_datetime(self.visit.get("arrival", ""))
        self.arrival_edit.setDateTime(arrival_value or QDateTime.currentDateTime())
        form.addRow("到达时间", self.arrival_edit)

        self.no_departure_checkbox = QCheckBox("暂不填写离开时间")
        departure_value = self._parse_datetime(self.visit.get("departure", ""))
        self.no_departure_checkbox.setChecked(departure_value is None)

        departure_row = QWidget()
        departure_layout = QVBoxLayout(departure_row)
        departure_layout.setContentsMargins(0, 0, 0, 0)
        departure_layout.setSpacing(6)
        self.departure_edit = QDateTimeEdit()
        self.departure_edit.setCalendarPopup(True)
        self.departure_edit.setDisplayFormat("yyyy-MM-dd HH:mm")
        self.departure_edit.setDateTime(departure_value or QDateTime.currentDateTime())
        self.departure_edit.setEnabled(departure_value is not None)
        departure_layout.addWidget(self.departure_edit)
        departure_layout.addWidget(self.no_departure_checkbox)
        self.no_departure_checkbox.toggled.connect(
            lambda checked: self.departure_edit.setEnabled(not checked)
        )
        form.addRow("离开时间", departure_row)

        self.content_edit = QTextEdit()
        self.content_edit.setPlaceholderText("记录在这座城市的经历、去过的地方等……")
        self.content_edit.setMinimumHeight(125)
        self.content_edit.setPlainText(self.visit.get("content", ""))
        form.addRow("记录内容", self.content_edit)

        self.note_edit = QTextEdit()
        self.note_edit.setPlaceholderText("写下这段经历带给你的感受……")
        self.note_edit.setMinimumHeight(95)
        self.note_edit.setPlainText(self.visit.get("note", ""))
        form.addRow("个人感想", self.note_edit)

        layout.addLayout(form, 1)

        buttons = QDialogButtonBox(
            QDialogButtonBox.Save | QDialogButtonBox.Cancel
        )
        buttons.button(QDialogButtonBox.Save).setText("保存记录")
        buttons.button(QDialogButtonBox.Cancel).setText("取消")
        buttons.accepted.connect(self.validate_and_accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    @staticmethod
    def _parse_datetime(value):
        if not value:
            return None
        value = str(value).strip()
        for fmt in ("yyyy-MM-dd HH:mm", "yyyy-MM-dd"):
            parsed = QDateTime.fromString(value, fmt)
            if parsed.isValid():
                return parsed
        return None

    def validate_and_accept(self):
        if not self.title_edit.text().strip():
            QMessageBox.warning(self, "提示", "请填写记录标题。")
            self.title_edit.setFocus()
            return

        if not self.no_departure_checkbox.isChecked():
            if self.departure_edit.dateTime() < self.arrival_edit.dateTime():
                QMessageBox.warning(self, "时间不合理", "离开时间不能早于到达时间。")
                return

        self.accept()

    def get_record_data(self):
        arrival = self.arrival_edit.dateTime().toString("yyyy-MM-dd HH:mm")
        departure = ""
        if not self.no_departure_checkbox.isChecked():
            departure = self.departure_edit.dateTime().toString("yyyy-MM-dd HH:mm")

        return {
            "id": self.visit.get("id", str(uuid4())),
            "date": arrival[:10],
            "arrival": arrival,
            "departure": departure,
            "title": self.title_edit.text().strip(),
            "content": self.content_edit.toPlainText().strip(),
            "note": self.note_edit.toPlainText().strip(),
        }


# ==================================================
# 6. 主窗口
# ==================================================

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("中国旅行足迹地图")
        self.resize(1500, 900)
        self.setMinimumSize(1100, 700)

        self.current_city = None

        self.setStyleSheet("""
            QMainWindow, QWidget {
                background: #F7F9FC;
                color: #27364A;
                font-family: "Microsoft YaHei";
                font-size: 13px;
            }
            QLabel { background: transparent; }
            QFrame#panel {
                background: white;
                border: 1px solid #E7EBF0;
                border-radius: 10px;
            }
            QLineEdit, QTextEdit, QDateTimeEdit, QComboBox {
                background: #F8FAFC;
                border: 1px solid #DCE3EA;
                border-radius: 6px;
                padding: 8px;
            }
            QPushButton {
                background: #3988D6;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 9px 15px;
            }
            QPushButton:hover { background: #2875C0; }
            QPushButton:disabled {
                background: #E8EDF3;
                color: #98A2B3;
            }
            QPushButton#secondary {
                background: #EDF2F7;
                color: #344054;
            }
            QPushButton#secondary:hover { background: #E2E8F0; }
            QPushButton#danger {
                background: #FCE8E8;
                color: #C03939;
            }
            QPushButton#danger:hover { background: #F9D5D5; }
            QListWidget {
                background: #F8FAFC;
                border: 1px solid #E7EBF0;
                border-radius: 6px;
                padding: 4px;
            }
            QListWidget::item {
                padding: 8px 6px;
                border-radius: 4px;
            }
            QListWidget::item:selected {
                background: #FBE8EE;
                color: #8F405A;
            }
            QLabel#heading {
                font-size: 19px;
                font-weight: bold;
            }
            QLabel#stat {
                font-size: 25px;
                font-weight: bold;
                color: #3988D6;
            }
            QLabel#muted { color: #8492A6; }
        """)

        self.build_ui()
        self.refresh_all()

        if DATA_LOAD_WARNING:
            QMessageBox.warning(self, "数据读取提醒", DATA_LOAD_WARNING)

    # --------------------------------------------------
    # 主界面
    # --------------------------------------------------

    def build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(14, 12, 14, 12)
        root.setSpacing(12)

        header = QHBoxLayout()
        title = QLabel("中国旅行足迹")
        title.setObjectName("heading")
        header.addWidget(title)
        header.addStretch()

        self.selected_city_label = QLabel("尚未选择城市")
        self.selected_city_label.setObjectName("muted")
        header.addWidget(self.selected_city_label)
        root.addLayout(header)

        stats = QHBoxLayout()
        self.stat_cities, self.city_progress = self.make_stat("到访城市")
        self.stat_provinces, self.province_progress = self.make_stat("到访省级行政区")
        stats.addWidget(self.stat_cities[0], 1)
        stats.addWidget(self.stat_provinces[0], 1)
        root.addLayout(stats)

        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(self.build_left_panel())
        splitter.addWidget(self.build_map_panel())
        splitter.setSizes([320, 1130])
        splitter.setStretchFactor(1, 1)
        root.addWidget(splitter, 1)

    def make_stat(self, label):
        frame = QFrame()
        frame.setObjectName("panel")
        box = QVBoxLayout(frame)
        box.setContentsMargins(16, 10, 16, 10)
        box.setSpacing(5)

        top = QHBoxLayout()
        name = QLabel(label)
        name.setObjectName("muted")
        value = QLabel("0 / 0")
        value.setObjectName("stat")
        top.addWidget(name)
        top.addStretch()
        top.addWidget(value)
        box.addLayout(top)

        percent = QLabel("0.0%")
        percent.setStyleSheet("font-size: 20px; font-weight: bold; color: #3988D6;")
        box.addWidget(percent)

        progress = QProgressBar()
        progress.setRange(0, 1000)
        progress.setValue(0)
        progress.setTextVisible(False)
        progress.setFixedHeight(8)
        progress.setStyleSheet(
            "QProgressBar { background: #E9EEF4; border: none; border-radius: 4px; }"
            "QProgressBar::chunk { background: #3988D6; border-radius: 4px; }"
        )
        box.addWidget(progress)
        caption = "占全国城市总数比例" if label == "到访城市" else "占全国省级行政区总数比例"
        box.addWidget(QLabel(caption))

        return (frame, value, percent), progress

    def build_left_panel(self):
        panel = QFrame()
        panel.setObjectName("panel")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(14, 16, 14, 14)
        layout.setSpacing(9)

        layout.addWidget(QLabel("城市搜索"))
        search_row = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("输入城市名称，例如：北京")
        search_row.addWidget(self.search, 1)

        self.add_footprint_button = QPushButton("添加足迹")
        self.add_footprint_button.setObjectName("secondary")
        self.add_footprint_button.setEnabled(False)
        self.add_footprint_button.clicked.connect(self.add_footprint)
        search_row.addWidget(self.add_footprint_button)
        layout.addLayout(search_row)

        self.city_list = QListWidget()
        self.city_list.setMinimumHeight(150)
        layout.addWidget(self.city_list, 1)
        self.search.textChanged.connect(self.search_cities)
        self.city_list.itemClicked.connect(self.select_city)

        visited_header = QHBoxLayout()
        visited_header.addWidget(QLabel("已到访城市"))
        visited_header.addStretch()
        self.delete_footprint_button = QPushButton("删除足迹")
        self.delete_footprint_button.setObjectName("danger")
        self.delete_footprint_button.setEnabled(False)
        self.delete_footprint_button.setToolTip("删除左侧列表中当前选中的城市足迹")
        self.delete_footprint_button.clicked.connect(self.delete_footprint)
        visited_header.addWidget(self.delete_footprint_button)
        layout.addLayout(visited_header)

        self.visited_list = QListWidget()
        self.visited_list.setMinimumHeight(170)
        layout.addWidget(self.visited_list, 1)
        self.visited_list.itemClicked.connect(self.select_visited_city)
        self.visited_list.currentItemChanged.connect(self.on_visited_selection_changed)

        return panel

    def build_map_panel(self):
        panel = QFrame()
        panel.setObjectName("panel")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(5, 5, 5, 5)

        self.map_view = QWebEngineView()
        self.map_html_path = DATA_DIR / "map_view.html"
        self.map_html_path.write_text(create_map_html(), encoding="utf-8")

        # 页面加载前先建立 WebChannel，确保地图点击事件能够传回 Python。
        self.web_channel = QWebChannel(self.map_view.page())
        self.map_bridge = MapBridge(self)
        self.web_channel.registerObject("mapBridge", self.map_bridge)
        self.map_view.page().setWebChannel(self.web_channel)

        self.map_view.loadFinished.connect(self.on_map_load_finished)
        self.map_view.load(QUrl.fromLocalFile(str(self.map_html_path.resolve())))
        layout.addWidget(self.map_view)
        return panel

    def on_map_load_finished(self, success):
        if not success:
            QMessageBox.warning(
                self,
                "地图页面加载失败",
                "地图页面未能正常加载。请检查 data 文件夹中的地图文件和 echarts.min.js。",
            )
            return
        self.update_map()

    # --------------------------------------------------
    # 城市搜索与选择
    # --------------------------------------------------

    def search_cities(self, text):
        self.city_list.clear()
        keyword = text.strip()
        if not keyword:
            return

        results = [
            city for city in CITIES
            if keyword.lower() in city["name"].lower()
            or keyword.lower() in city["province"].lower()
        ]

        for city in results[:100]:
            item = QListWidgetItem(f'{city["name"]}    {city["province"]}')
            item.setData(Qt.UserRole, city["code"])
            self.city_list.addItem(item)

    def set_current_city(self, city):
        self.current_city = city
        self.selected_city_label.setText(f'{city["name"]} · {city["code"]}')
        is_visited = bool(records.get(city["code"], {}).get("footprint", False))
        self.add_footprint_button.setEnabled(not is_visited)
        self.add_footprint_button.setText("已添加" if is_visited else "添加足迹")

    def select_city(self, item):
        code = str(item.data(Qt.UserRole))
        city = CITY_BY_CODE.get(code)
        if not city:
            return
        self.set_current_city(city)

        # 搜索结果中若是已添加足迹的城市，点击后直接打开城市记录界面。
        if records.get(code, {}).get("footprint", False):
            self.open_city_detail(city)

    def select_visited_city(self, item):
        code = str(item.data(Qt.UserRole))
        city = CITY_BY_CODE.get(code)
        if city and records.get(code, {}).get("footprint", False):
            self.set_current_city(city)
            self.open_city_detail(city)

    def on_visited_selection_changed(self, current, previous):
        self.delete_footprint_button.setEnabled(current is not None)

    def open_city_from_map(self, city_code):
        """地图点击入口：未添加足迹的城市直接忽略，不弹窗、不提示。"""
        city_code = str(city_code)
        city = CITY_BY_CODE.get(city_code)
        city_data = records.get(city_code, {})
        if not city or not city_data.get("footprint", False):
            return
        self.set_current_city(city)
        self.open_city_detail(city)

    # --------------------------------------------------
    # 添加、删除城市足迹
    # --------------------------------------------------

    def add_footprint(self):
        if not self.current_city:
            QMessageBox.information(self, "提示", "请先在左侧搜索并选择一座城市。")
            return

        code = self.current_city["code"]
        city_data = records.setdefault(code, {
            "name": self.current_city["name"],
            "province": self.current_city["province"],
            "footprint": False,
            "label": "",
            "visits": [],
        })

        if city_data.get("footprint", False):
            return

        city_data["name"] = self.current_city["name"]
        city_data["province"] = self.current_city["province"]
        city_data["footprint"] = True
        city_data.setdefault("label", "")
        city_data.setdefault("visits", [])

        save_records()
        self.refresh_all()
        self.set_current_city(self.current_city)

    def delete_footprint(self):
        item = self.visited_list.currentItem()
        if item is None:
            QMessageBox.information(self, "提示", "请先在已到访城市列表中选择要删除的城市。")
            return

        code = str(item.data(Qt.UserRole))
        city = CITY_BY_CODE.get(code)
        city_data = records.get(code)
        if not city or not city_data or not city_data.get("footprint", False):
            return

        answer = QMessageBox.question(
            self,
            "确认删除足迹",
            f'确定删除「{city["name"]}」的城市足迹吗？\n\n'
            "这只会取消地图上的足迹标记，不会删除已有历史记录。",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return

        city_data["footprint"] = False
        # 无记录的误添加城市可以从数据中移除；已有记录则保留，重新添加足迹后仍可查看。
        if not city_data.get("visits"):
            records.pop(code, None)

        save_records()
        self.refresh_all()
        if self.current_city and self.current_city["code"] == code:
            self.set_current_city(self.current_city)

    # --------------------------------------------------
    # 城市详情：标签 + 大面积历史记录列表
    # --------------------------------------------------

    def open_city_detail(self, city):
        code = city["code"]
        city_data = records.get(code, {})
        if not city_data.get("footprint", False):
            return

        dialog = QDialog(self)
        dialog.setWindowTitle(f'{city["name"]} · 城市记录')
        dialog.resize(780, 760)
        dialog.setMinimumSize(620, 560)

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(20, 18, 20, 18)
        layout.setSpacing(12)

        heading = QLabel(f'{city["name"]} · 城市记录')
        heading.setObjectName("heading")
        layout.addWidget(heading)

        # 城市标签区域：既可选预设标签，也可直接输入自定义标签。
        label_row = QHBoxLayout()
        label_row.addWidget(QLabel("城市标签"))
        label_combo = QComboBox()
        label_combo.setEditable(True)
        label_combo.addItems(["家乡", "上学", "旅游"])
        label_combo.setCurrentIndex(-1)
        label_combo.setMinimumWidth(220)
        label_combo.setInsertPolicy(QComboBox.NoInsert)
        label_combo.lineEdit().setPlaceholderText("选择或自定义，例如：家乡、上学、旅游")
        saved_label = str(city_data.get("label", "") or "")
        if saved_label:
            label_combo.setEditText(saved_label)
        label_row.addWidget(label_combo, 1)

        save_label_button = QPushButton("保存标签")
        save_label_button.setObjectName("secondary")
        label_row.addWidget(save_label_button)
        layout.addLayout(label_row)

        label_status = QLabel("")
        label_status.setObjectName("muted")
        layout.addWidget(label_status)

        def save_city_label():
            latest_data = records.setdefault(code, {
                "name": city["name"],
                "province": city["province"],
                "footprint": True,
                "label": "",
                "visits": [],
            })
            latest_data["label"] = label_combo.currentText().strip()
            save_records()
            self.refresh_all()
            label_status.setText("标签已保存" if latest_data["label"] else "已清空城市标签")

        save_label_button.clicked.connect(save_city_label)

        history_title = QLabel("历史记录")
        history_title.setStyleSheet("font-size: 15px; font-weight: bold;")
        layout.addWidget(history_title)

        history_list = QListWidget()
        history_list.setSpacing(3)
        layout.addWidget(history_list, 1)

        self.refresh_city_record_list(code, history_list)
        history_list.itemClicked.connect(
            lambda item: self.open_record_detail(dialog, code, item.data(Qt.UserRole), history_list)
        )

        new_record_button = QPushButton("＋ 新建记录")
        new_record_button.clicked.connect(
            lambda: self.create_record(code, city, history_list)
        )
        layout.addWidget(new_record_button)

        dialog.exec()

    @staticmethod
    def record_sort_key(visit):
        return str(visit.get("arrival") or visit.get("date") or "")

    def refresh_city_record_list(self, city_code, list_widget):
        list_widget.clear()
        visits = records.get(city_code, {}).get("visits", [])
        visits = sorted(visits, key=self.record_sort_key, reverse=True)

        if not visits:
            empty_item = QListWidgetItem("还没有历史记录，点击下方按钮新建一条记录。")
            empty_item.setFlags(Qt.NoItemFlags)
            empty_item.setForeground(Qt.gray)
            list_widget.addItem(empty_item)
            return

        for visit in visits:
            arrival = str(visit.get("arrival") or visit.get("date") or "时间未填写")
            departure = str(visit.get("departure") or "尚未填写离开时间")
            title = str(visit.get("title") or "未命名记录")
            item = QListWidgetItem(f"{title}\n{arrival}  →  {departure}")
            item.setData(Qt.UserRole, visit["id"])
            list_widget.addItem(item)

    def create_record(self, city_code, city, list_widget):
        editor = RecordEditorDialog(self)
        if editor.exec() != QDialog.Accepted:
            return

        city_data = records.setdefault(city_code, {
            "name": city["name"],
            "province": city["province"],
            "footprint": True,
            "label": "",
            "visits": [],
        })
        # 城市详情只会从已添加足迹的城市打开，因此这里不因写日记而额外创建足迹。
        city_data.setdefault("visits", []).append(editor.get_record_data())
        save_records()
        self.refresh_city_record_list(city_code, list_widget)
        self.refresh_all()

    def open_record_detail(self, city_dialog, city_code, record_id, history_list):
        visits = records.get(city_code, {}).get("visits", [])
        visit = next((entry for entry in visits if entry.get("id") == record_id), None)
        if not visit:
            return

        detail = QDialog(city_dialog)
        detail.setWindowTitle("历史记录详情")
        detail.resize(620, 650)
        detail.setMinimumSize(500, 480)
        layout = QVBoxLayout(detail)
        layout.setContentsMargins(20, 18, 20, 18)
        layout.setSpacing(12)

        title = QLabel(visit.get("title", "未命名记录"))
        title.setObjectName("heading")
        layout.addWidget(title)

        arrival = visit.get("arrival") or visit.get("date") or "未填写"
        departure = visit.get("departure") or "尚未填写"
        time_label = QLabel(f"到达：{arrival}\n离开：{departure}")
        time_label.setObjectName("muted")
        layout.addWidget(time_label)

        content_title = QLabel("记录内容")
        content_title.setStyleSheet("font-weight: bold;")
        layout.addWidget(content_title)
        content_view = QTextEdit()
        content_view.setReadOnly(True)
        content_view.setPlainText(visit.get("content", "") or "（没有填写记录内容）")
        layout.addWidget(content_view, 2)

        note_title = QLabel("个人感想")
        note_title.setStyleSheet("font-weight: bold;")
        layout.addWidget(note_title)
        note_view = QTextEdit()
        note_view.setReadOnly(True)
        note_view.setPlainText(visit.get("note", "") or "（没有填写个人感想）")
        note_view.setMaximumHeight(125)
        layout.addWidget(note_view, 1)

        action_row = QHBoxLayout()
        action_row.addStretch()
        modify_button = QPushButton("修改记录")
        modify_button.setObjectName("secondary")
        delete_button = QPushButton("删除记录")
        delete_button.setObjectName("danger")
        close_button = QPushButton("关闭")
        close_button.setObjectName("secondary")
        action_row.addWidget(modify_button)
        action_row.addWidget(delete_button)
        action_row.addWidget(close_button)
        layout.addLayout(action_row)

        close_button.clicked.connect(detail.reject)

        def modify_record():
            current_visits = records.get(city_code, {}).get("visits", [])
            current_visit = next(
                (entry for entry in current_visits if entry.get("id") == record_id),
                None,
            )
            if not current_visit:
                detail.accept()
                return

            editor = RecordEditorDialog(detail, current_visit)
            if editor.exec() != QDialog.Accepted:
                return

            updated_data = editor.get_record_data()
            current_visit.clear()
            current_visit.update(updated_data)
            save_records()
            self.refresh_city_record_list(city_code, history_list)
            self.refresh_all()
            detail.accept()

        def remove_record():
            answer = QMessageBox.question(
                detail,
                "确认删除",
                "确定删除这条历史记录吗？此操作无法撤销。",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if answer != QMessageBox.Yes:
                return

            city_data = records.get(city_code, {})
            city_data["visits"] = [
                entry for entry in city_data.get("visits", [])
                if entry.get("id") != record_id
            ]
            # 删除日记不影响独立的城市足迹和城市标签。
            save_records()
            self.refresh_city_record_list(city_code, history_list)
            self.refresh_all()
            detail.accept()

        modify_button.clicked.connect(modify_record)
        delete_button.clicked.connect(remove_record)
        detail.exec()

    # --------------------------------------------------
    # 统计与地图更新
    # --------------------------------------------------

    def refresh_all(self):
        visited_codes = [
            code for code, city_data in records.items()
            if city_data.get("footprint", False) and code in CITY_BY_CODE
        ]

        visited_provinces = {CITY_BY_CODE[code]["province_code"] for code in visited_codes}
        total_cities = len(CITIES)
        total_provinces = 34
        city_ratio = len(visited_codes) / total_cities if total_cities else 0
        province_ratio = len(visited_provinces) / total_provinces if total_provinces else 0

        self.stat_cities[1].setText(f"{len(visited_codes)} / {total_cities}")
        self.stat_cities[2].setText(f"{city_ratio * 100:.1f}%")
        self.city_progress.setValue(round(city_ratio * 1000))
        self.stat_provinces[1].setText(f"{len(visited_provinces)} / {total_provinces}")
        self.stat_provinces[2].setText(f"{province_ratio * 100:.1f}%")
        self.province_progress.setValue(round(province_ratio * 1000))

        self.visited_list.clear()
        for city in CITIES:
            code = city["code"]
            city_data = records.get(code, {})
            if not city_data.get("footprint", False):
                continue

            visit_count = len(city_data.get("visits", []))
            label = str(city_data.get("label", "") or "").strip()
            pieces = [city["name"]]
            if label:
                pieces.append(label)
            pieces.append(f"{visit_count}条记录" if visit_count else "已添加")
            item = QListWidgetItem("  ·  ".join(pieces))
            item.setData(Qt.UserRole, code)
            self.visited_list.addItem(item)

        self.update_map()

        if self.current_city:
            self.set_current_city(self.current_city)

    def update_map(self):
        names = [
            CITY_BY_CODE[code]["name"]
            for code, city_data in records.items()
            if city_data.get("footprint", False) and code in CITY_BY_CODE
        ]
        names_json = json.dumps(names, ensure_ascii=False)
        self.map_view.page().runJavaScript(
            f"window.__pendingVisited = {names_json}; "
            f"if (window.updateVisited) window.updateVisited({names_json});"
        )


# ==================================================
# 7. 启动程序
# ==================================================

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setFont(QFont("Microsoft YaHei", 10))

    window = MainWindow()
    window.show()

    sys.exit(app.exec())
